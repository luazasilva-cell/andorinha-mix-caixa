# Andorinha Mix — Caixa V1

Sistema simples de 1 caixa, sem login e sem servidor.

## Como usar
Abra `index.html` no navegador. Os dados ficam salvos no navegador (localStorage).

## GitHub
1. Crie um repositório no GitHub.
2. Envie o arquivo `index.html`.
3. Em Settings > Pages, publique a branch principal.
